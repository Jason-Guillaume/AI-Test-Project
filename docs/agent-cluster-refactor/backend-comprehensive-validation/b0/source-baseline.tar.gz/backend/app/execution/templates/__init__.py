"""跨领域模板解析入口；只解释调用方提供的纯数据上下文。"""

from app.execution.templates.resolver import RequestContext, ResolveScope, resolve_template, resolve_token_str

__all__ = ["RequestContext", "ResolveScope", "resolve_template", "resolve_token_str"]

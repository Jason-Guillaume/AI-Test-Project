"""任务运行处理器的可信上下文和窄协作接口。

Worker 从数据库装配任务身份、运行、工作项与执行尝试；处理器只取得本阶段需要的模型、
入队、资源、事件和控制边界能力，不接收整个 Worker 或 TaskService。
"""

from dataclasses import dataclass
from typing import Any, Callable

from sqlalchemy.orm import Session

from app.core.models.identity import User
from app.features.tasks.models import (
    Task,
    TaskAgentInstance,
    TaskAttempt,
    TaskEvent,
    TaskResourceRef,
    TaskRun,
    TaskWorkItem,
)


@dataclass(frozen=True)
class TaskHandlerContext:
    """由 Worker 可信装配的单次处理上下文，不接受模型输入覆盖。"""

    db: Session
    task: Task
    run: TaskRun
    work: TaskWorkItem
    attempt: TaskAttempt
    agent: TaskAgentInstance | None
    actor: User


@dataclass(frozen=True)
class TaskHandlerServices:
    """报告和审阅处理器需要的有限运行时协作能力。"""

    provider_for_agent: Callable[..., Any]
    enqueue_work: Callable[..., TaskWorkItem]
    add_worker_resource: Callable[..., TaskResourceRef]
    append_event: Callable[..., TaskEvent]
    defer_at_control_boundary: Callable[..., bool]


def require_agent_tool(run: TaskRun, agent: TaskAgentInstance, tool_name: str) -> None:
    """验证运行快照绑定 Agent 的工具白名单；旧流程保持原有默认能力。"""
    if (run.input_snapshot or {}).get("agent_definition") and tool_name not in (agent.tool_allowlist_json or []):
        raise RuntimeError(f"当前 Agent 未获授权使用工具：{tool_name}")

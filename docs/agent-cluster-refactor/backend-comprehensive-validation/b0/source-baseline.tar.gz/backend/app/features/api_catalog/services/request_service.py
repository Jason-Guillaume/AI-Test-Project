"""接口请求子资源公开读取契约。

调试执行和接口管理通过本模块读取参数与请求体；HTTP 执行能力不直接访问 api_catalog 私有查询实现。
"""

from __future__ import annotations

from sqlalchemy.orm import Session

from app.features.api_catalog.models.api_parameter import ApiParameter
from app.features.api_catalog.models.api_request_body import ApiRequestBody


def load_interface_request_params(db: Session, interface_id: int) -> list[ApiParameter]:
    """按既有 sort、id 顺序加载接口参数。"""
    return (
        db.query(ApiParameter)
        .filter(ApiParameter.interface_id == interface_id)
        .order_by(ApiParameter.sort.asc(), ApiParameter.id.asc())
        .all()
    )


def load_interface_request_body(db: Session, interface_id: int) -> ApiRequestBody | None:
    """加载接口唯一请求体；缺少记录时返回 None。"""
    return (
        db.query(ApiRequestBody)
        .filter(ApiRequestBody.interface_id == interface_id)
        .one_or_none()
    )


__all__ = ["load_interface_request_body", "load_interface_request_params"]

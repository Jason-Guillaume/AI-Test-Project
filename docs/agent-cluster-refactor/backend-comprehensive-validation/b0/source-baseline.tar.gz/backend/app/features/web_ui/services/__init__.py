"""Web UI 功能的公开服务入口。"""

from app.features.web_ui.services.draft_service import generate_draft
from app.features.web_ui.services.web_ui_service import WebUIService

__all__ = ["WebUIService", "generate_draft"]

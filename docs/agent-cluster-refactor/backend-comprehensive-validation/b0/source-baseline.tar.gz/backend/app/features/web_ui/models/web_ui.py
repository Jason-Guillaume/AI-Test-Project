"""Web UI 扩展表；用例与步骤仍使用 TestCase/TestStep，执行仍使用 TestRun/CaseExecution。"""
from sqlalchemy import Column, DateTime, ForeignKey, Integer, JSON, String, Text, UniqueConstraint
from sqlalchemy.sql import func
from app.core.database.base import Base


class PageObject(Base):
    """项目内页面对象：命名元素仅保存声明式定位器。"""
    __tablename__ = "web_page_object"
    __table_args__ = (UniqueConstraint("project_id", "name", name="uq_web_page_project_name"),)
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("project.id", ondelete="CASCADE"), nullable=False, index=True)
    name = Column(String(200), nullable=False)
    path = Column(String(2000), nullable=False)
    elements = Column(JSON, nullable=False)
    revision = Column(Integer, nullable=False, default=1, server_default="1")
    created_at = Column(DateTime, nullable=False, server_default=func.now())


class WebAuthProfile(Base):
    """加密测试账号或人工完成扫码后的 storage_state；API 永不返回明文。"""
    __tablename__ = "web_auth_profile"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("project.id", ondelete="CASCADE"), nullable=False, index=True)
    environment_id = Column(Integer, ForeignKey("environment.id", ondelete="CASCADE"), nullable=False)
    name = Column(String(200), nullable=False)
    secret_encrypted = Column(Text, nullable=False)
    expires_at = Column(DateTime, nullable=False)
    created_by = Column(Integer, ForeignKey("user.id", ondelete="SET NULL"))
    created_at = Column(DateTime, nullable=False, server_default=func.now())


class WebCase(Base):
    """既有用例的 Web 执行配置与人工确认指纹，修改依赖后必须重新确认。"""
    __tablename__ = "web_case"
    test_case_id = Column(Integer, ForeignKey("test_case.id", ondelete="CASCADE"), primary_key=True)
    auth_profile_id = Column(Integer, ForeignKey("web_auth_profile.id", ondelete="SET NULL"))
    timeout_ms = Column(Integer, nullable=False, default=30000, server_default="30000")
    total_timeout_ms = Column(Integer, nullable=False, default=120000, server_default="120000")
    confirmed_digest = Column(String(64))
    confirmed_by = Column(Integer, ForeignKey("user.id", ondelete="SET NULL"))


class WebArtifact(Base):
    """截图和脱敏 Trace 加密落库；每个附件继承项目权限，不暴露文件系统路径。"""
    __tablename__ = "web_artifact"
    id = Column(String(36), primary_key=True)
    project_id = Column(Integer, ForeignKey("project.id", ondelete="CASCADE"), nullable=False, index=True)
    test_case_id = Column(Integer, ForeignKey("test_case.id", ondelete="SET NULL"))
    case_execution_id = Column(Integer, ForeignKey("case_execution.id", ondelete="CASCADE"), index=True)
    kind = Column(String(20), nullable=False)
    content_encrypted = Column(Text, nullable=False)
    created_at = Column(DateTime, nullable=False, server_default=func.now())


class WebAgentSession(Base):
    """智能体二轮受控浏览器会话；仅记录目标与预算，不执行任何正式用例。"""
    __tablename__ = "web_agent_session"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("project.id", ondelete="CASCADE"), nullable=False, index=True)
    environment_id = Column(Integer, ForeignKey("environment.id", ondelete="CASCADE"), nullable=False)
    auth_profile_id = Column(Integer, ForeignKey("web_auth_profile.id", ondelete="SET NULL"))
    base_url = Column(String(2000), nullable=False)
    target_page_path = Column(String(2000), nullable=False, default="", server_default="")
    status = Column(String(16), nullable=False, default="ACTIVE", server_default="ACTIVE")
    step_budget = Column(Integer, nullable=False, default=20, server_default="20")
    created_by = Column(Integer, ForeignKey("user.id", ondelete="SET NULL"))
    created_at = Column(DateTime, nullable=False, server_default=func.now())
    closed_at = Column(DateTime)
    task_run_id = Column(Integer, ForeignKey("task_run.id", ondelete="CASCADE"), nullable=True, index=True)
    task_agent_instance_id = Column(Integer, ForeignKey("task_agent_instance.id", ondelete="SET NULL"), nullable=True)
    agent_session_id = Column(Integer, ForeignKey("agent_session.id", ondelete="SET NULL"), nullable=True, index=True)


class WebAgentStep(Base):
    """智能体已执行步骤；步骤与结果加密落库，只有通过的步骤可提升为正式用例。"""
    __tablename__ = "web_agent_step"
    id = Column(Integer, primary_key=True)
    session_id = Column(Integer, ForeignKey("web_agent_session.id", ondelete="CASCADE"), nullable=False, index=True)
    sort = Column(Integer, nullable=False, default=0, server_default="0")
    step_encrypted = Column(Text, nullable=False)
    observation_encrypted = Column(Text)
    status = Column(String(16), nullable=False, default="PROPOSED", server_default="PROPOSED")
    source = Column(String(8), nullable=False, default="AI", server_default="AI")
    created_at = Column(DateTime, nullable=False, server_default=func.now())

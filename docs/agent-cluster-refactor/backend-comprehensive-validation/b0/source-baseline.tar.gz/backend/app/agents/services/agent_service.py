"""Agent 定义治理服务。

负责 Agent 配置、依赖校验、版本快照及与工具授权页面有关的聚合读写；任务状态和运行快照由任务域持有。
"""
from __future__ import annotations
import re
import uuid
from typing import Any
from sqlalchemy import func
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session
from app.agents.schemas import AgentDefinitionCreate, AgentDefinitionUpdate, AgentRuntimeSettings
from app.agents.models import AgentDefinition, AgentDefinitionRevision
from app.mcp.models import MCPServer
from app.mcp.services import mcp_service
from app.skills.models import SkillDefinition, SkillDefinitionRevision, SkillUsageEvent
from app.skills.schemas import SkillUpdate
from app.skills.services import skill_service
from app.tools.catalog import BUILTIN_TOOLS, TOOL_BY_KEY
from app.tools.models import ToolDefinitionOverride
from app.core.models.configuration import ModelConfiguration
from app.core.http.errors import bad_request, conflict, not_found


def _validate_agent_links(
    db: Session,
    skill_keys: list[str],
    tool_keys: list[str],
    model_config_id: int | None,
    *,
    agent_enabled: bool,
    child_agent_ids: list[int],
    agent_id: int | None = None,
) -> None:
    """校验 Agent 关联的 Skill、内置/MCP 工具和最多一层的叶子子 Agent。"""
    if len(set(skill_keys)) != len(skill_keys) or len(set(tool_keys)) != len(tool_keys):
        raise bad_request("Skill 和工具不能重复关联")
    skills = db.query(SkillDefinition).filter(SkillDefinition.key.in_(skill_keys)).all() if skill_keys else []
    if len({row.key for row in skills}) != len(set(skill_keys)):
        raise bad_request("Agent 关联的 Skill 不存在")
    if agent_enabled and any(not row.is_enabled for row in skills):
        raise bad_request("启用 Agent 前，请先启用其关联的 Skill")
    mcp_refs: list[tuple[int, str]] = []
    unknown_tools = set()
    for key in set(tool_keys):
        if key in TOOL_BY_KEY:
            override = db.get(ToolDefinitionOverride, key)
            if override is not None and not override.is_enabled:
                raise bad_request(f"工具「{TOOL_BY_KEY[key]['name']}」已停用")
            continue
        match = re.fullmatch(r"mcp:(\d+):(.+)", key)
        if match:
            mcp_refs.append((int(match.group(1)), match.group(2)))
        else:
            unknown_tools.add(key)
    if unknown_tools:
        raise bad_request("Agent 包含平台未注册的工具")
    for server_id, tool_name in mcp_refs:
        server = db.get(MCPServer, server_id)
        if server is None:
            raise bad_request("Agent 关联的 MCP 服务不存在")
        discovered = {item.get("name"): item for item in (server.discovered_tools_json or [])}
        tool = discovered.get(tool_name)
        if tool is None:
            raise bad_request("Agent 关联的 MCP 工具未在最近发现结果中")
        if agent_enabled:
            if not server.is_enabled or server.connection_status != "connected" or tool_name not in (server.approved_tools_json or []):
                raise bad_request("启用 Agent 前，请确保 MCP 服务已启用、连接且工具获批")
            if (tool.get("annotations") or {}).get("readOnlyHint") is not True:
                raise bad_request("只有明确标注为只读的 MCP 工具可以由任务 Agent 自动调用")
    child_ids = list(dict.fromkeys(int(item) for item in child_agent_ids))
    if len(child_ids) != len(child_agent_ids) or len(child_ids) > 8:
        raise bad_request("子 Agent 不能重复，且最多选择 8 个")
    if agent_id is not None and agent_id in child_ids:
        raise bad_request("Agent 不能将自身配置为子 Agent")
    if child_ids:
        children = db.query(AgentDefinition).filter(AgentDefinition.id.in_(child_ids)).all()
        child_by_id = {item.id: item for item in children}
        if len(child_by_id) != len(child_ids):
            raise bad_request("所选子 Agent 不存在")
        if any(item.child_agent_ids for item in children):
            raise bad_request("子 Agent 目前只支持叶子节点，不能继续嵌套")
        if any(item.tool_keys for item in children):
            raise bad_request("子 Agent 当前只承担分析职责，请移除其工具授权后再关联")
        if agent_enabled and any(not item.is_enabled for item in children):
            raise bad_request("启用父 Agent 前，请先启用全部子 Agent")
    if agent_id is not None and child_agent_ids and any(
        agent_id in (item.child_agent_ids or [])
        for item in db.query(AgentDefinition).filter(AgentDefinition.id != agent_id).all()
    ):
        raise bad_request("已被其他 Agent 作为子节点引用的配置不能再嵌套子 Agent")
    if agent_id is not None and tool_keys and any(
        agent_id in (item.child_agent_ids or [])
        for item in db.query(AgentDefinition).filter(AgentDefinition.id != agent_id).all()
    ):
        raise bad_request("作为子 Agent 的配置只承担分析职责，不能授权工具")
    if model_config_id is not None:
        model = db.get(ModelConfiguration, model_config_id)
        if model is None:
            raise bad_request("所选模型配置不存在")
        if agent_enabled and not model.is_enabled:
            raise bad_request("启用 Agent 前，请先启用其关联的模型配置")

def _agent_snapshot(row: AgentDefinition) -> dict[str, Any]:
    """生成智能体定义的版本快照。"""
    return {
        "name": row.name,
        "description": row.description,
        "workflow_template": row.workflow_template,
        "instruction": row.instruction,
        "model_config_id": row.model_config_id,
        "skill_keys": row.skill_keys or [],
        "tool_keys": row.tool_keys or [],
        "child_agent_ids": row.child_agent_ids or [],
        "is_enabled": row.is_enabled,
        "settings_json": row.settings_json or AgentRuntimeSettings().model_dump(mode="json"),
        "triggers_json": row.triggers_json or [],
    }

def list_agents(db: Session) -> list[AgentDefinition]:
    """列出`agents`。"""
    return db.query(AgentDefinition).order_by(AgentDefinition.updated_at.desc(), AgentDefinition.id.desc()).all()

def create_agent(db: Session, body: AgentDefinitionCreate, actor_id: int) -> AgentDefinition:
    """创建智能体。"""
    _validate_agent_links(
        db, body.skill_keys, body.tool_keys, body.model_config_id,
        agent_enabled=body.is_enabled, child_agent_ids=body.child_agent_ids,
    )
    row = AgentDefinition(
        key=str(uuid.uuid4()),
        **body.model_dump(mode="json"),
        created_by=actor_id,
        updated_by=actor_id,
    )
    db.add(row)
    db.flush()
    db.add(AgentDefinitionRevision(
        agent_definition_id=row.id,
        version=row.version,
        snapshot_json=_agent_snapshot(row),
        created_by=actor_id,
    ))
    db.commit()
    db.refresh(row)
    return row

def update_agent(db: Session, agent_id: int, body: AgentDefinitionUpdate, actor_id: int) -> AgentDefinition:
    """更新智能体。"""
    row = db.get(AgentDefinition, agent_id)
    if row is None:
        raise not_found("Agent 配置不存在")
    changes = body.model_dump(exclude_unset=True, mode="json")
    changes = {
        key: value for key, value in changes.items()
        if value is not None or key in {"model_config_id", "skill_keys", "tool_keys"}
    }
    if "settings_json" not in changes and "model_config_id" in changes:
        legacy_settings = dict(row.settings_json or AgentRuntimeSettings().model_dump(mode="json"))
        legacy_settings["model_binding"] = "agent" if changes["model_config_id"] is not None else "task_or_global"
        changes["settings_json"] = AgentRuntimeSettings.model_validate(legacy_settings).model_dump(mode="json")
    if changes:
        effective_settings = changes.get("settings_json", row.settings_json or {})
        binding = effective_settings.get("model_binding", "task_or_global")
        effective_model_id = changes.get("model_config_id", row.model_config_id)
        if binding == "task_or_global":
            changes["model_config_id"] = None
        elif effective_model_id is None:
            raise bad_request("选择 Agent 固定模型时必须指定模型配置")
    if changes.get("is_enabled") is False and any(
        row.id in (parent.child_agent_ids or []) and parent.is_enabled
        for parent in db.query(AgentDefinition).filter(AgentDefinition.id != row.id).all()
    ):
        raise conflict("该 Agent 正被启用中的父 Agent 使用，请先停用父 Agent 或移除引用")
    for key in ("skill_keys", "tool_keys"):
        if key in changes and changes[key] is None:
            changes[key] = []
    _validate_agent_links(
        db,
        changes.get("skill_keys", row.skill_keys or []) or [],
        changes.get("tool_keys", row.tool_keys or []) or [],
        changes.get("model_config_id", row.model_config_id),
        agent_enabled=changes.get("is_enabled", row.is_enabled),
        child_agent_ids=changes.get("child_agent_ids", row.child_agent_ids or []) or [],
        agent_id=row.id,
    )
    if changes:
        for key, value in changes.items():
            setattr(row, key, value)
        row.version += 1
        row.updated_by = actor_id
        db.add(AgentDefinitionRevision(
            agent_definition_id=row.id,
            version=row.version,
            snapshot_json=_agent_snapshot(row),
            created_by=actor_id,
        ))
        db.commit()
        db.refresh(row)
    return row

def agent_versions(db: Session, agent_id: int) -> list[AgentDefinitionRevision]:
    """列出智能体定义的历史版本。"""
    if db.get(AgentDefinition, agent_id) is None:
        raise not_found("Agent 配置不存在")
    return db.query(AgentDefinitionRevision).filter(
        AgentDefinitionRevision.agent_definition_id == agent_id
    ).order_by(AgentDefinitionRevision.version.desc()).all()

def delete_agent(db: Session, agent_id: int) -> None:
    """删除智能体。"""
    row = db.get(AgentDefinition, agent_id)
    if row is None:
        raise not_found("Agent 配置不存在")
    if any(agent_id in (item.child_agent_ids or []) for item in db.query(AgentDefinition).filter(AgentDefinition.id != agent_id).all()):
        raise conflict("该 Agent 已被其他 Agent 配置为子节点，请先移除引用")
    db.delete(row)
    try:
        db.commit()
    except IntegrityError as exc:
        db.rollback()
        raise conflict("已有任务绑定此 Agent，请停用配置而不是删除") from exc

def list_builtin_tools(db: Session) -> list[dict[str, Any]]:
    """列出内置`tools`。"""
    overrides = {row.tool_key: row for row in db.query(ToolDefinitionOverride).all()}
    agents_by_tool: dict[str, list[int]] = {key: [] for key in TOOL_BY_KEY}
    for agent in db.query(AgentDefinition).all():
        for key in agent.tool_keys or []:
            if key in agents_by_tool:
                agents_by_tool[key].append(agent.id)
    result = []
    for tool in BUILTIN_TOOLS:
        override = overrides.get(tool["key"])
        parameter_overrides = (override.parameter_overrides_json or {}) if override else {}
        runtime_details = tool.get("runtime_details", {})
        parameters = [
            {
                **parameter,
                "description": parameter_overrides.get(parameter["name"], {}).get("description", parameter["description"]),
                **({"default": parameter_overrides[parameter["name"]]["default"]} if "default" in parameter_overrides.get(parameter["name"], {}) else {}),
            }
            for parameter in tool.get("parameters", [])
        ]
        runtime_details = {
            **runtime_details,
            "input_context": [
                {
                    **field,
                    "description": parameter_overrides.get(field["name"], {}).get("description", field["description"]),
                }
                for field in runtime_details.get("input_context", [])
            ],
        }
        result.append({
            **tool,
            "description": override.description if override else tool["description"],
            "parameter_overrides_json": parameter_overrides,
            "is_enabled": override.is_enabled if override else True,
            "agent_ids": agents_by_tool[tool["key"]],
            "parameters": parameters,
            "runtime_details": runtime_details,
        })
    return result

def restore_agent_version(db: Session, agent_id: int, version: int, actor_id: int) -> AgentDefinition:
    """将历史快照恢复为当前配置，并作为新的版本保存。"""
    revision = db.query(AgentDefinitionRevision).filter_by(agent_definition_id=agent_id, version=version).first()
    if revision is None:
        raise not_found("Agent 历史版本不存在")
    allowed = {
        "name", "description", "workflow_template", "instruction", "model_config_id",
        "skill_keys", "tool_keys", "child_agent_ids", "is_enabled", "settings_json", "triggers_json",
    }
    body = AgentDefinitionUpdate.model_validate({key: value for key, value in revision.snapshot_json.items() if key in allowed})
    return update_agent(db, agent_id, body, actor_id)



def validate_agent_links(*args: Any, **kwargs: Any) -> None:
    """公开 Agent 依赖校验契约，供工具配置聚合服务复用。"""
    _validate_agent_links(*args, **kwargs)


def agent_revision_snapshot(row: AgentDefinition) -> dict[str, Any]:
    """返回供同一事务创建 Agent 修订记录使用的公开快照。"""
    return _agent_snapshot(row)


from app.tools.schemas import ToolDefinitionUpdate
from app.tools.services.tool_service import apply_tool_override, restore_tool_override


def update_builtin_tool(
    db: Session, tool_key: str, body: ToolDefinitionUpdate, actor_id: int,
) -> dict[str, Any]:
    """更新工具说明及 Agent 授权，并记录受影响 Agent 的新版本。"""
    if tool_key not in TOOL_BY_KEY:
        raise not_found("平台工具不存在")
    agents = db.query(AgentDefinition).all()
    agents_by_id = {agent.id: agent for agent in agents}
    selected_ids = set(body.agent_ids) if body.is_enabled else set()
    if selected_ids - agents_by_id.keys():
        raise bad_request("所选 Agent 不存在")
    updates: list[tuple[AgentDefinition, list[str]]] = []
    for agent in agents:
        current_keys = list(agent.tool_keys or [])
        has_tool = tool_key in current_keys
        should_have_tool = agent.id in selected_ids
        if has_tool == should_have_tool:
            continue
        next_keys = current_keys if should_have_tool else [key for key in current_keys if key != tool_key]
        if should_have_tool:
            next_keys.append(tool_key)
            _validate_agent_links(
                db, agent.skill_keys or [], next_keys, agent.model_config_id,
                agent_enabled=agent.is_enabled, child_agent_ids=agent.child_agent_ids or [],
                agent_id=agent.id,
            )
        updates.append((agent, next_keys))
    # 工具覆写与 Agent 修订共享 Session，确保授权和工具状态一并提交。
    apply_tool_override(db, tool_key, body, actor_id)
    for agent, tool_keys in updates:
        agent.tool_keys = tool_keys
        agent.version += 1
        agent.updated_by = actor_id
        db.add(AgentDefinitionRevision(
            agent_definition_id=agent.id, version=agent.version,
            snapshot_json=_agent_snapshot(agent), created_by=actor_id,
        ))
    db.commit()
    return next(item for item in list_builtin_tools(db) if item["key"] == tool_key)


def restore_builtin_tool_defaults(db: Session, tool_key: str, actor_id: int) -> dict[str, Any]:
    """恢复工具目录默认值，不改变 Agent 授权列表。"""
    override = restore_tool_override(db, tool_key, actor_id)
    if override is not None:
        db.commit()
    return next(item for item in list_builtin_tools(db) if item["key"] == tool_key)


def update_skill(db: Session, skill_id: int, body: SkillUpdate, actor_id: int) -> SkillDefinition:
    """更新 Skill，并保护仍由启用 Agent 使用的定义。"""
    row = db.get(SkillDefinition, skill_id)
    if row is None:
        raise not_found("Skill 不存在")
    changes = body.model_dump(exclude_unset=True)
    if changes.get("is_enabled") is False and any(
        row.is_enabled and row.key in (agent.skill_keys or [])
        for agent in db.query(AgentDefinition).all()
    ):
        raise conflict("该 Skill 正被启用中的 Agent 使用，请先停用 Agent 或移除引用")
    return skill_service.update_skill(db, skill_id, body, actor_id)


def delete_skill(db: Session, skill_id: int) -> None:
    """删除未被 Agent 配置引用的 Skill。"""
    row = db.get(SkillDefinition, skill_id)
    if row is None:
        raise not_found("Skill 不存在")
    if any(row.key in (agent.skill_keys or []) for agent in db.query(AgentDefinition).all()):
        raise conflict("该 Skill 已被 Agent 引用，请先从 Agent 配置中移除")
    skill_service.remove_skill(db, skill_id)


def skill_usage(db: Session, skill_id: int) -> dict[str, Any]:
    """汇总 Skill 使用记录、Agent 名称和近期任务。"""
    from app.features.tasks.models.task import Task, TaskRun

    skill = db.get(SkillDefinition, skill_id)
    if skill is None:
        raise not_found("Skill 不存在")
    query = db.query(SkillUsageEvent).filter(SkillUsageEvent.skill_definition_id == skill_id)
    total_loads = query.count()
    last_used_at = query.with_entities(func.max(SkillUsageEvent.created_at)).scalar()
    agent_rows = db.query(
        AgentDefinition.id, AgentDefinition.name, func.count(SkillUsageEvent.id),
    ).join(
        SkillUsageEvent, SkillUsageEvent.agent_definition_id == AgentDefinition.id,
    ).filter(SkillUsageEvent.skill_definition_id == skill_id).group_by(
        AgentDefinition.id, AgentDefinition.name,
    ).all()
    recent = db.query(SkillUsageEvent, TaskRun, Task).join(
        TaskRun, TaskRun.id == SkillUsageEvent.task_run_id,
    ).join(Task, Task.id == TaskRun.task_id).filter(
        SkillUsageEvent.skill_definition_id == skill_id,
    ).order_by(SkillUsageEvent.created_at.desc()).limit(10).all()
    return {
        "total_loads": total_loads,
        "task_count": query.with_entities(
            func.count(func.distinct(SkillUsageEvent.task_run_id)),
        ).scalar() or 0,
        "last_used_at": last_used_at,
        "agents": [{"id": row[0], "name": row[1], "loads": row[2]} for row in agent_rows],
        "recent_tasks": [
            {"task_id": task.id, "title": task.title, "run_number": run.run_number, "used_at": event.created_at}
            for event, run, task in recent
        ],
    }


def delete_mcp_server(db: Session, server_id: int) -> None:
    """删除未被 Agent 工具授权引用的 MCP 服务。"""
    if db.get(MCPServer, server_id) is None:
        raise not_found("MCP 服务不存在")
    prefix = f"mcp:{server_id}:"
    if any(
        any(str(key).startswith(prefix) for key in (agent.tool_keys or []))
        for agent in db.query(AgentDefinition).all()
    ):
        raise conflict("该 MCP 服务仍被 Agent 引用，请先移除 Agent 工具授权；紧急停用可直接关闭服务")
    mcp_service.remove_mcp_server(db, server_id)


def restore_skill_version(db: Session, skill_id: int, version: int, actor_id: int) -> SkillDefinition:
    """恢复 Skill 历史版本，并沿用启用引用保护。"""
    revision = db.query(SkillDefinitionRevision).filter_by(
        skill_definition_id=skill_id, version=version,
    ).first()
    if revision is None:
        raise not_found("Skill 历史版本不存在")
    allowed = {"name", "description", "content", "is_enabled", "files_json", "mcp_tool_keys_json"}
    body = SkillUpdate.model_validate({
        key: value for key, value in revision.snapshot_json.items() if key in allowed
    })
    return update_skill(db, skill_id, body, actor_id)
